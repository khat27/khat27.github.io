package appsToon;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Vector;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class RegisterForm extends JFrame{

	private JLabel title = new JLabel("APPS TOON", SwingConstants.CENTER);
	private JLabel lUsern = new JLabel("Username");
	private JLabel lEmail = new JLabel("Email");
	private JLabel lPass = new JLabel("Password");
	private JLabel lConfirmPass = new JLabel("Confirm Password");
	private JLabel lGender = new JLabel("Gender");
	private JLabel lDob = new JLabel("DOB");
	private JLabel lPhone = new JLabel("Phone Number");
	private JLabel lAddress = new JLabel("Address");
	
	private JTextField tfUsern = new JTextField(15);
	private JTextField tfEmail = new JTextField(15);
	private JTextField tfPhone = new JTextField(15);
	private JTextField tfAddress = new JTextField(15);
	
	private JPasswordField pfPass = new JPasswordField(15);
	private JPasswordField pfConfirmPass = new JPasswordField(15);
	
	private String[] months = new String[] {
			
			"Month",
			"January",
			"February",
			"March",
			"April",
			"May",
			"June",
			"July",
			"August",
			"September",
			"October",
			"November",
			"December"
	};
	
	private Vector<String> vecDays = new Vector<>();
	private Vector<String> vecYears = new Vector<>();
	
	private JComboBox<String> year;
	private JComboBox<String> month = new JComboBox<>(months);
	private JComboBox<String> day;
	
	private ButtonGroup gender = new ButtonGroup();
	private JRadioButton genderMale = new JRadioButton("Male");
	private JRadioButton genderFemale = new JRadioButton("Female");
	
	private JButton submit = new JButton("Submit");
	private JButton cancel = new JButton("Cancel");
	
	private JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
	private JPanel fieldPanel = new JPanel(new GridLayout(8, 2, 18, 18));
	private JPanel genderPanel = new JPanel(new GridLayout(1, 2, 10, 10));
	private JPanel radioPanel = new JPanel(new GridLayout(1, 3, 10, 10));
	private JPanel buttonPanel = new JPanel(new GridLayout(1, 2, 18, 10));
	
	public RegisterForm() {
		
		initComponents();
		
		setContentPane(mainPanel);
		setSize(400, 500);
		setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        setTitle("Apps Toon");
        setVisible(true);
	}
	
	public void dobVal() {
		
		vecYears.add("Year");
        
		for(int i = 1900; i < 2020; i++) {
			
			vecYears.add(i + "");
		}
		
		vecDays.add("Day");
		
		for(int i = 0; i < 31; i++) {
			
			vecDays.add(i + 1 + "");
		}
		
		year = new JComboBox<String>(vecYears);
		day = new JComboBox<String>(vecDays);
	}
	
	public void initComponents() {
		
		title.setFont(new Font(title.getFont().getName(), Font.BOLD, 20));
		dobVal();
		actions();
		
		genderMale.setActionCommand("Male");
		genderFemale.setActionCommand("Female");
        
    	gender.add(genderMale);
    	gender.add(genderFemale);
        genderPanel.add(genderMale);
        genderPanel.add(genderFemale);
		
		radioPanel.add(day);
		radioPanel.add(month);
		radioPanel.add(year);
        
        fieldPanel.add(lUsern);
        fieldPanel.add(tfUsern);
        fieldPanel.add(lEmail);
        fieldPanel.add(tfEmail);
        fieldPanel.add(lPass);
        fieldPanel.add(pfPass);
        fieldPanel.add(lConfirmPass);
        fieldPanel.add(pfConfirmPass);
        fieldPanel.add(lGender);
        fieldPanel.add(genderPanel);
        fieldPanel.add(lDob);
        fieldPanel.add(radioPanel);
        fieldPanel.add(lPhone);
        fieldPanel.add(tfPhone);
        fieldPanel.add(lAddress);
        fieldPanel.add(tfAddress);
		
		buttonPanel.add(cancel);
		buttonPanel.add(submit);
		buttonPanel.setBorder(BorderFactory.createEmptyBorder(15, 5, 5, 5));
        
        mainPanel.add(title, BorderLayout.NORTH);
        mainPanel.add(fieldPanel, BorderLayout.CENTER);
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
	}
	
	public void actions() {
		
		submit.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				validation();
			}
		});
		
		cancel.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent arg0) {
					// TODO Auto-generated method stub
					tfUsern.setText("");
					tfEmail.setText("");
					tfAddress.setText("");
					tfPhone.setText("");
					gender.clearSelection();
					year.setSelectedIndex(0);
					month.setSelectedIndex(0);
					day.setSelectedIndex(0);
					pfConfirmPass.setText("");
					pfPass.setText("");
				}
		});
	}
	
	public void validation() {
		
		if (tfUsern.getText().length() < 5 || tfUsern.getText().length() > 20) {
			
			JOptionPane.showMessageDialog(null, "Username length must be between 5 and 20 characters", "Error", JOptionPane.ERROR_MESSAGE);
		} 
		else if (tfEmail.getText().length() <= 14) 
		{
			
			JOptionPane.showMessageDialog(null, "Email length must be more than 14 characters", "Error", JOptionPane.ERROR_MESSAGE);
		} 
		else if (!tfEmail.getText().contains("@") && !tfEmail.getText().contains(".")) 
		{
			
			JOptionPane.showMessageDialog(null, "Email must contain '@' and '.'", "Error", JOptionPane.ERROR_MESSAGE);
		} 
		else if (checkDuplicate(tfEmail.getText())) 
		{
			
			JOptionPane.showMessageDialog(null, "Email must not contain more than 1 '@' or '.'", "Error", JOptionPane.ERROR_MESSAGE);
		} 
		else if (tfEmail.getText().indexOf("@") - tfEmail.getText().indexOf(".") == 1 || 
				tfEmail.getText().indexOf("@") - tfEmail.getText().indexOf(".") == -1) 
		{
			
			JOptionPane.showMessageDialog(null, "Character '@' must not be next to '.'", "Error", JOptionPane.ERROR_MESSAGE);
		} 
		else if (tfEmail.getText().indexOf("@") == 0 || tfEmail.getText().indexOf(".") == 0) 
		{
			
			JOptionPane.showMessageDialog(null, "Email must not start with '@' or '.'", "Error", JOptionPane.ERROR_MESSAGE);
		} 
		else if (!tfEmail.getText().endsWith(".com")) 
		{
			
			JOptionPane.showMessageDialog(null, "Email must end with '.com'", "Error", JOptionPane.ERROR_MESSAGE);
		} 
		else if (pfPass.getText().length() <= 10) 
		{
			
			JOptionPane.showMessageDialog(null, "Password length must be more than 10 characters", "Error", JOptionPane.ERROR_MESSAGE);
		} 
		else if (isAlphaNumeric(pfPass.getText()) || isNumeric(pfPass.getText())) 
		{
			
			JOptionPane.showMessageDialog(null, "Password must be alphanumeric", "Error", JOptionPane.ERROR_MESSAGE);
		} 
		else if (!pfConfirmPass.getText().equals(pfPass.getText())) 
		{
			
			JOptionPane.showMessageDialog(null, "Confirm Password must be the same with Password", "Error", JOptionPane.ERROR_MESSAGE);
		} 
		else if (gender.getSelection() == null) 
		{
			
			JOptionPane.showMessageDialog(null, "Gender must be selected", "Error", JOptionPane.ERROR_MESSAGE);
		} 
		else if (year.getSelectedIndex() == 0 || month.getSelectedIndex() == 0 || 
				day.getSelectedIndex() == 0) 
		{
			
			JOptionPane.showMessageDialog(null, "Day of birth must be selected", "Error", JOptionPane.ERROR_MESSAGE);
		} 
		else if (checkPhone(tfPhone.getText())) 
		{
			
			JOptionPane.showMessageDialog(null, "Phone number must be numeric", "Error", JOptionPane.ERROR_MESSAGE);
		} 
		else if (tfPhone.getText().length() != 12) 
		{
			
			JOptionPane.showMessageDialog(null, "Phone number length must be 12 digits", "Error", JOptionPane.ERROR_MESSAGE);
		} 
		else if (tfAddress.getText().length() < 6 || tfAddress.getText().length() > 30) 
		{
			
			JOptionPane.showMessageDialog(null, "Address length must be between 6 and 30 characters", "Error", JOptionPane.ERROR_MESSAGE);
		} 
		else if (!tfAddress.getText().endsWith(" Street")) 
		{
			
			JOptionPane.showMessageDialog(null, "Address must ends with 'Street'", "Error", JOptionPane.ERROR_MESSAGE);
		} 
		else 
		{
			
	       insertData();
		}
	}
	
	public void insertData() {
		
		try{  
        	Class.forName("com.mysql.jdbc.Driver");  
        	Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3306/AppsToon","root","");
        	Statement s = c.createStatement();
        	ResultSet rs = s.executeQuery(
        			"SELECT Username "
        			+ "FROM User "
        			+ "WHERE UserName = '" + tfUsern.getText() + "';");
        	
        	if (rs.first()) {
				
        		JOptionPane.showMessageDialog(null, "Username already exists", "Error", JOptionPane.ERROR_MESSAGE);
			}
        	
        	rs = s.executeQuery(
        			"SELECT UserEmail "
        			+ "FROM User "
        			+ "WHERE UserEmail = '" + tfEmail.getText() + "';");
        	
        	if (rs.first()) {
				
        		JOptionPane.showMessageDialog(null, "Email already exists", "Error", JOptionPane.ERROR_MESSAGE);
			}
        	
        	rs = s.executeQuery(
        			"SELECT UserPassword "
        			+ "FROM User "
        			+ "WHERE BINARY UserPassword = '" + pfPass.getText() + "';");
        	
        	if (rs.first()) {
				
        		JOptionPane.showMessageDialog(null, "Password already exists", "Error", JOptionPane.ERROR_MESSAGE);
			}
        	
        	rs = s.executeQuery(
        			"SELECT UserId "
        			+ "FROM User "
        			+ "WHERE UserId = 'US001';");
        	
        	String sql = "INSERT INTO User VALUES (?,?,?,?,?,?,?,?,?)";
        	PreparedStatement ps = c.prepareStatement(sql);
        	
        	if (!rs.next()) {
        		
	        	ps.setString(1, "US001");
	        	ps.setString(2, tfUsern.getText());
	        	ps.setString(3, tfEmail.getText());
	        	ps.setString(4, pfPass.getText());
	        	ps.setString(5, gender.getSelection().getActionCommand());
	        	ps.setString(6, year.getSelectedItem() + "-" + month.getSelectedIndex() + "-" + day.getSelectedItem());
	        	ps.setString(7, tfPhone.getText());
	        	ps.setString(8, tfAddress.getText());
	        	ps.setString(9, "User");
	        	
	        	ps.executeUpdate();
			} 
        	
        	rs = s.executeQuery(
        			"SELECT UserId "
        			+ "FROM User "
        			+ "ORDER BY UserId DESC LIMIT 1");
        	
        	if (rs.next()) {
				
        		String id = String.format("%03d", Integer.parseInt(rs.getString("UserId").substring(2)) + 1);
        		id = "US" + id;
        		
        		ps.setString(1, id);
	        	ps.setString(2, tfUsern.getText());
	        	ps.setString(3, tfEmail.getText());
	        	ps.setString(4, pfPass.getText());
	        	ps.setString(5, gender.getSelection().getActionCommand());
	        	ps.setString(6, year.getSelectedItem() + "-" + month.getSelectedIndex() + "-" + day.getSelectedItem());
	        	ps.setString(7, tfPhone.getText());
	        	ps.setString(8, tfAddress.getText());
        		ps.setString(9, "User");
        		
        		ps.executeUpdate();
	        	
	        	JOptionPane.showMessageDialog(null, "Register Success");
	        	
	        	dispose();
	        	new LoginForm();
			}
        	
        }catch(Exception e1){ 
        	
        	System.out.println(e1);
        }
	}
	
	public boolean checkPhone(String num) {
		
		for (int i = 0; i < num.length(); i++) {
			
			if (!Character.isDigit(num.charAt(i))) {
				
				return true;
			}
		} return false;
	}
	
	public boolean checkDuplicate(String dup) {
		
		if (dup.length() - dup.replace("@", "").length() > 1 || 
				dup.length() - dup.replace(".", "").length() > 1) {
			
			return true;
		} return false;
	}
	
	
	public boolean isNumeric(String pass) {
		
		String temp = "1234567890";
		
		for(int i = 0; i < pass.length(); i++) {
			
			if(temp.contains(pass.charAt(i) + "")) {
				
				return false;
			}
		} return true;
	}
	
	public boolean isAlphaNumeric(String pass) {
		
		String temp = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
		
		for (int i = 0; i < pass.length(); i++) {
			
			if (temp.contains(pass.charAt(i) + "")) {
				
				return false;
			}
		} return true;
	}
}
