package appsToon;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JDesktopPane;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

public class MainFormStaff extends JFrame{

	private JDesktopPane dp = new JDesktopPane();
	
	private JMenuBar mb = new JMenuBar();
	
	private JMenu manage = new JMenu("Manage");
	private JMenu transaction = new JMenu("Transaction");
	
	private JMenuItem user = new JMenuItem("User");
	private JMenuItem product = new JMenuItem("Product");
	private JMenuItem view = new JMenuItem("View Transaction");
	
	private JMenuItem logout = new JMenuItem("Logout");
	
	public MainFormStaff() {
		// TODO Auto-generated constructor stub
		initComponents();
		
		setContentPane(dp);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setExtendedState(getExtendedState() | MAXIMIZED_BOTH);
		setSize(700, 600);
		setLocationRelativeTo(null);
		setVisible(true);
	}
	
	public void initComponents() {
		
		actions();
		
		manage.add(user);
		manage.add(product);
		
		transaction.add(view);
		
		mb.add(manage);
		mb.add(transaction);
		mb.add(logout);
		
		setJMenuBar(mb);
	}

	public void actions() {
		
		logout.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				dispose();
				new LoginForm();
			}
		});	
		
		product.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				getContentPane().add(new ManageProductForm());
			}
		});
		
		view.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				getContentPane().add(new StaffTransactionForm());
			}
		});
	}
}
