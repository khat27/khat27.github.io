package appsToon;

import java.awt.Font;
import java.awt.GridLayout;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;

class UserTransactionForm extends JInternalFrame{

	Temporary temp = new Temporary();
	
	private DefaultTableModel headerModel = new DefaultTableModel(new Object[] {
			
			"TransactionID",
			"UserID",
			"Date"
	}, 0) {
		
		public boolean isCellEditable(int row, int column) {
			
			return false;
		};
	};
	
	private DefaultTableModel detailModel = new DefaultTableModel(new Object[] {
			
		"TransactionID",
		"ProductID",
		"Qty"
	}, 0) {
		
		public boolean isCellEditable(int row, int column) {
			
			return false;
		};
	};
	
	private JTable tableHeader = new JTable(headerModel);
	private JTable tableDetail = new JTable(detailModel);
	
	private JLabel header = new JLabel("Transaction List", SwingConstants.CENTER);
	private JLabel detail = new JLabel("Transaction Detail", SwingConstants.CENTER);
	
	private JPanel mainPanel = new JPanel(new GridLayout(2, 1, 10, 10));
	private JPanel headerPanel = new JPanel(new GridLayout(2, 1, 10, 10));
	private JPanel detailPanel = new JPanel(new GridLayout(2, 1, 10, 10));
	
	public UserTransactionForm() {
		// TODO Auto-generated constructor stub
		initcomponents();
		
		setMaximizable(true);
		setClosable(true);
		setResizable(false);
		setSize(500, 500);
		setLocation(50, 50);
		show();
	}

	public void initcomponents() {

		tableHeader.setFocusable(false);
		tableHeader.setRowSelectionAllowed(true);
		
		tableDetail.setFocusable(false);
		tableDetail.setRowSelectionAllowed(false);
		
		fetchData();
		
		tableHeader.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
			
			@Override
			public void valueChanged(ListSelectionEvent e) {
				// TODO Auto-generated method stub
				fetchDetail();
			}
		});
		
		header.setFont(new Font(header.getFont().getName(), Font.BOLD, 20));
		detail.setFont(new Font(header.getFont().getName(), Font.BOLD, 20));
		
		headerPanel.add(header);
		headerPanel.add(new JScrollPane(tableHeader));
		detailPanel.add(detail);
		detailPanel.add(new JScrollPane(tableDetail));
		
		mainPanel.add(headerPanel);
		mainPanel.add(detailPanel);
		
		getContentPane().add(mainPanel);
	}
	
	public void fetchData() {
		
//		Fetch Header
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3306/appstoon", "root", "");
			Statement s = c.createStatement();
			ResultSet rs = s.executeQuery(
					"SELECT * FROM HeaderTransaction "
					+ "WHERE UserId LIKE '" + temp.getId() + "';"
					);
			
			while (rs.next()) {
				
				headerModel.addRow(new Object[] {
						
						rs.getString(1),
						rs.getString(2),
						rs.getString(3)
				});
			}
			
			rs = s.executeQuery(
					"SELECT DetailTransaction.TransactionId, ProductId, Qty "
					+ "FROM DetailTransaction JOIN HeaderTransaction "
					+ 	"ON DetailTransaction.TransactionId = HeaderTransaction.TransactionId "
					+ "WHERE UserId LIKE '" + temp.getId() + "';"
					);
			
			while (rs.next()) {
				
				detailModel.addRow(new Object[] {
						
						rs.getString(1),
						rs.getString(2),
						rs.getString(3)
				});
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void fetchDetail() {
		
		detailModel.setRowCount(0);
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3306/appstoon", "root", "");
			Statement s = c.createStatement();
			ResultSet rs = s.executeQuery(
					"SELECT * "
					+ "FROM DetailTransaction "
					+ "WHERE TransactionId LIKE '" + tableHeader.getValueAt(tableHeader.getSelectedRow(), 0) + "';"
					);
			
			while (rs.next()) {
				
				detailModel.addRow(new Object[] {
						
						rs.getString(1),
						rs.getString(2),
						rs.getString(3)
				});
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
