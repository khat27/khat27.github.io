package appsToon;

import javax.swing.JInternalFrame;

class Temporary {
	
	private static String id = "";
	private static String usern = "";
	private static int total = 0;
	private static JInternalFrame jif;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		Temporary.id = id;
	}

	public String getUsern() {
		return usern;
	}

	public void setUsern(String usern) {
		Temporary.usern = usern;
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		Temporary.total = total;
	}

	public static JInternalFrame getJif() {
		return jif;
	}

	public static void setInf(JInternalFrame jif) {
		Temporary.jif = jif;
	}
}
