package appsToon;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingConstants;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;

public class ManageProductForm extends JInternalFrame{

	private JLabel title = new JLabel("Product List", SwingConstants.CENTER);
	private JLabel id = new JLabel("Product ID");
	private JLabel name = new JLabel("Product Name");
	private JLabel price = new JLabel("Product Price");
	private JLabel rating = new JLabel("Product Rating");
	private JLabel stock = new JLabel("Product Stock");
	private JLabel genre = new JLabel("Genre");
	private JLabel image = new JLabel("Product Image");
	
	private JTextField tfId = new JTextField();
	private JTextField tfName = new JTextField();
	private JTextField tfPrice = new JTextField();
	private JTextField tfRating = new JTextField();
	private JTextField tfImage = new JTextField();
	
	private JSpinner spinner = new JSpinner(new SpinnerNumberModel(1, 1, 100, 1));
	
	private JComboBox comboGenre;
	
	private JButton choose = new JButton("Choose");
	private JButton insert = new JButton("Insert");
	private JButton update = new JButton("Update");
	private JButton delete = new JButton("Delete");
	private JButton submit = new JButton("Submit");
	private JButton cancel = new JButton("Cancel");
	
	private String[] columnNames = new String[]{
		"ProductID",
		"GenreName",
		"ProductName",
		"ProductPrice",
		"ProductQuantity",
		"ProductImage",
		"ProductRating"
	};
	
	private DefaultTableModel model = new DefaultTableModel(columnNames, 0) {
		
		public boolean isCellEditable(int row, int column) {
			return false;
		};
	};
	
	private JTable table = new JTable(model);
	
	private JPanel mainPanel = new JPanel(new BorderLayout(5, 5));
	private JPanel panel1 = new JPanel(new GridLayout(2, 1, 5, 5));
	private JPanel panel2 = new JPanel(new BorderLayout(5, 5));
	private JPanel panel3 = new JPanel(new GridLayout(1, 2, 5, 5));
	private JPanel panel4 = new JPanel(new GridLayout(7, 2, 5, 5));
	private JPanel panel5 = new JPanel(new GridLayout(5, 1, 5, 5));
	private JPanel panel6 = new JPanel(new GridLayout(1, 2));
	
	private JLabel icon = new JLabel();
	private String path = "";
	private String tempS = "";
	
	public ManageProductForm() {
		// TODO Auto-generated constructor stub
		initComponents();
		
		setClosable(true);
		setMaximizable(true);
		setContentPane(mainPanel);
		setTitle("Manage Products");
		setSize(700, 600);
		show();
	}

	public void initComponents() {
		
		title.setFont(new Font(title.getFont().getName(), Font.BOLD, 20));
		table.getTableHeader().setReorderingAllowed(false);
		fetchData();
		setGenre();
		actions();
		
		panel6.add(tfImage);
		panel6.add(choose);
		
		panel5.add(insert);
		panel5.add(update);
		panel5.add(delete);
		panel5.add(submit);
		panel5.add(cancel);
		
		panel4.add(id);
		panel4.add(tfId);
		panel4.add(name);
		panel4.add(tfName);
		panel4.add(price);
		panel4.add(tfPrice);
		panel4.add(rating);
		panel4.add(tfRating);
		panel4.add(stock);
		panel4.add(spinner);
		panel4.add(genre);
		panel4.add(comboGenre);
		panel4.add(image);
		panel4.add(panel6);
		setClear();
		
		panel3.add(panel4);
		
		icon.setIcon(new ImageIcon(new ImageIcon(
				getClass().getResource("/No_Image.jpg")).getImage().getScaledInstance(
						180, 180, Image.SCALE_SMOOTH)));
		icon.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
		
		panel2.add(icon, BorderLayout.WEST);
		panel2.add(panel3, BorderLayout.CENTER);
		panel2.add(panel5, BorderLayout.EAST);
		
		panel1.add(new JScrollPane(table));
		panel1.add(panel2);
		
		mainPanel.add(title, BorderLayout.NORTH);
		mainPanel.add(panel1, BorderLayout.CENTER);
		mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
	}
	
	public void fetchData() {
		
		model.setRowCount(0);
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3306/AppsToon", "root", "");
			Statement s = c.createStatement();
			ResultSet rs = s.executeQuery(
					"SELECT ProductId, " + 
					"GenreName, " + 
					"ProductName, " + 
					"ProductPrice, " + 
					"ProductQuantity, " + 
					"CASE " + 
					"WHEN ProductImage LIKE '/resources/%' "
					+ "THEN SUBSTRING(ProductImage, (LENGTH(ProductImage) - LOCATE('/', REVERSE(ProductImage)) + 2), LOCATE('/', REVERSE(ProductImage))) " + 
					"ELSE " + 
					"SUBSTRING(ProductImage, (LENGTH(ProductImage) - LOCATE('\\\\', REVERSE(ProductImage)) + 2), LOCATE('\\\\', REVERSE(ProductImage))) " + 
					"END AS a, " + 
					"ProductRating " + 
					"FROM Product JOIN Genre ON Product.GenreId = Genre.GenreId"
					);
			
			while (rs.next()) {
				
				model.addRow(new Object[] {
						rs.getString(1), 
						rs.getString(2), 
						rs.getString(3), 
						rs.getString(4), 
						rs.getString(5), 
						rs.getString(6), 
						rs.getString(7)
						});
			}
			
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}
	
	public void setClear() {
		
		tfId.setEnabled(false);
		tfId.setEditable(false);
		tfImage.setEnabled(false);
		tfImage.setEditable(false);
		tfName.setEnabled(false);
		tfName.setEditable(false);
		tfPrice.setEnabled(false);
		tfPrice.setEditable(false);
		tfRating.setEnabled(false);
		tfRating.setEditable(false);
		comboGenre.setEnabled(false);
		comboGenre.setEditable(false);
		spinner.setEnabled(false);
		choose.setEnabled(false);
		submit.setEnabled(false);
		cancel.setEnabled(false);
		
		insert.setEnabled(true);
		update.setEnabled(true);
		delete.setEnabled(true);
	}
	
	public void enableTextField() {
		
		tfImage.setEnabled(true);
		tfImage.setEditable(true);
		tfName.setEnabled(true);
		tfName.setEditable(true);
		tfPrice.setEnabled(true);
		tfPrice.setEditable(true);
		tfRating.setEnabled(true);
		tfRating.setEditable(true);
		comboGenre.setEnabled(true);
		spinner.setEnabled(true);
		submit.setEnabled(true);
		choose.setEnabled(true);
		cancel.setEnabled(true);
		
		insert.setEnabled(false);
		update.setEnabled(false);
		delete.setEnabled(false);
	}
	
	public void insert() {
		
		enableTextField();
		tfId.setText(null);
		tfImage.setText(null);
		tfName.setText(null);
		tfPrice.setText(null);
		tfRating.setText(null);
		
		int temp = 0;
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3306/AppsToon", "root", "");
			Statement s = c.createStatement();
			ResultSet rs = s.executeQuery(
					"SELECT ProductId "
					+ "FROM Product "
					+ "ORDER BY ProductId DESC LIMIT 1;"
					);
			
			if (rs.first()) {
				
				tempS = "PD" + String.format(
						"%03d", Integer.parseInt(rs.getString("ProductId").substring(2)) + 1);
			} else {
				
				tempS = "PD001";
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		tfId.setText(tempS);
	}
	
	public void actions() {
		
		choose.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				JFileChooser choose = new JFileChooser();
				choose.setFileSelectionMode(JFileChooser.FILES_ONLY);
				
				if (choose.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
					
					try {
						
						icon.setIcon(new ImageIcon(new ImageIcon(
								ImageIO.read(choose.getSelectedFile())).getImage().getScaledInstance(
										180, 180, Image.SCALE_SMOOTH)));
						
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
				
				try {
					
					if (choose.getSelectedFile().getAbsolutePath().contains("\\resources\\")) {
						
						path = choose.getSelectedFile().getAbsolutePath().substring(
								choose.getSelectedFile().getAbsolutePath().indexOf("\\resources\\"));
						System.out.println(path);
					}
					
				} catch (NullPointerException e2) {
					// TODO: handle exception
					e2.printStackTrace();
				}
				
				tfImage.setText(choose.getSelectedFile().getName());
			}
		});
				
		insert.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				insert();
				submit.addActionListener(new ActionListener() {
					
					@Override
					public void actionPerformed(ActionEvent e) {
						// TODO Auto-generated method stub
						validation();
					}
				});
			}
		});
		
		cancel.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				tfId.setText(null);;
				tfImage.setText(null);
				tfName.setText(null);
				tfPrice.setText(null);
				tfRating.setText(null);
				icon.setIcon(new ImageIcon(getClass().getResource("/No_Image.jpg")));
				setClear();
			}
		});
		
		table.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
			
			@Override
			public void valueChanged(ListSelectionEvent arg0) {
				// TODO Auto-generated method stub
				selectData();
			}
		});
		
		
		delete.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				if (table.getSelectionModel().isSelectionEmpty()) {
					
					JOptionPane.showMessageDialog(null, "Data must be selected", "", JOptionPane.ERROR_MESSAGE);
				} else {
					
					try {
						Class.forName("com.mysql.jdbc.Driver");
						Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3306/AppsToon", "root", "");
						PreparedStatement ps = c.prepareStatement(
								"DELETE FROM Product "
								+ "WHERE ProductId LIKE ?"
								);
								
						ps.setString(1, table.getValueAt(table.getSelectedRow(), 0) + "");
						ps.executeUpdate();
						JOptionPane.showMessageDialog(null, "Delete Success", "Message", JOptionPane.INFORMATION_MESSAGE);
						fetchData();
					} catch (ClassNotFoundException | SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
			}
		});
		
		update.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				enableTextField();
				tfId.setEnabled(true);
				tfId.setEditable(true);
				if (table.getSelectionModel().isSelectionEmpty()) {
					
					JOptionPane.showMessageDialog(null, "Data must be selected", "", JOptionPane.ERROR_MESSAGE);
				} else {
					
					submit.addActionListener(new ActionListener() {
						
						@Override
						public void actionPerformed(ActionEvent arg0) {
							// TODO Auto-generated method stub
							updateData();
							setClear();
							tfId.setEnabled(false);
							tfId.setEditable(false);
							table.getSelectionModel().clearSelection();
						}
					});
				}
			}
		});
	}
	
	public void validation() {
		
		if (tfImage.getText().length() == 0 || tfName.getText().length() == 0 || 
				tfPrice.getText().length() == 0 || tfRating.getText().length() == 0) {
			
			JOptionPane.showMessageDialog(null, "All fields must be filled", "Message", JOptionPane.ERROR_MESSAGE);
		} else if (comboGenre.getSelectedIndex() == 0) {
			
			JOptionPane.showMessageDialog(null, "Genre must be selected", "Message", JOptionPane.ERROR_MESSAGE);
		} else if ((Integer) spinner.getValue() < 1) {
			
			JOptionPane.showMessageDialog(null, "Minimum product stock is 1", "Message", JOptionPane.ERROR_MESSAGE);
		} else if (checkPhone(tfPrice.getText())) {
			
			JOptionPane.showMessageDialog(null, "Price must be numeric", "Message", JOptionPane.ERROR_MESSAGE);
		} else {
			
			try {
				Class.forName("com.mysql.jdbc.Driver");
				Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3306/AppsToon", "root", "");

				PreparedStatement ps = c.prepareStatement(
						"INSERT INTO Product "
						+ "VALUES (?, ?, ?, ?, ?, ?, ?)"
						);
				String genreId = "GE" + String.format("%03d", comboGenre.getSelectedIndex());
				
				ps.setString(1, tempS);
				ps.setString(2, genreId);
				ps.setString(3, tfName.getText());
				ps.setInt(4, Integer.parseInt(tfPrice.getText()));
				ps.setInt(5, (Integer) spinner.getValue());
				ps.setString(6, path);
				ps.setString(7, tfRating.getText());
				
				ps.executeUpdate();
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			fetchData();
			setClear();
		}
	}
	
	public boolean checkPhone(String num) {
		
		for (int i = 0; i < num.length(); i++) {
			
			if (!Character.isDigit(num.charAt(i))) {
				
				return true;
			}
		} return false;
	}
	
	public void selectData() {
		
		try {
			
			tfId.setText(table.getValueAt(table.getSelectedRow(), 0) + "");
			tfName.setText(table.getValueAt(table.getSelectedRow(), 2) + "");
			tfPrice.setText(table.getValueAt(table.getSelectedRow(), 3) + "");
			tfImage.setText(table.getValueAt(table.getSelectedRow(), 5) + "");
			comboGenre.setSelectedItem(table.getValueAt(table.getSelectedRow(), 1) + "");
			tfRating.setText(table.getValueAt(table.getSelectedRow(), 6) + "");
			updateImage();
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	public void updateData() {
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3306/AppsToon", "root", "");
			Statement s = c.createStatement();
			PreparedStatement ps = c.prepareStatement(
					"UPDATE Product "
					+ "SET ProductId = ?, "
						+ "ProductName = ?, "
						+ "ProductPrice = ?, "
						+ "ProductRating = ?, "
						+ "ProductQuantity = ?, "
						+ "GenreId = ?, "
						+ "ProductImage = ? "
					+ "WHERE ProductId = ?;"
					);
			
			ps.setString(1, tfId.getText().toString());
			ps.setString(2, tfName.getText().toString());
			ps.setString(3, tfPrice.getText().toString());
			ps.setString(4, tfRating.getText().toString());
			ps.setString(5, spinner.getValue().toString());
			ps.setString(6, "GE" + String.format("%03d", comboGenre.getSelectedIndex()));
			
			ResultSet rs = s.executeQuery(
					"SELECT ProductImage "
					+ "FROM Product "
					+ "WHERE ProductId LIKE '%" + tfId.getText() + "';"
					);
			
			if (rs.next()) {
				
				if (tfImage.getText().equals(table.getValueAt(table.getSelectedRow(), 5))) {
					
					ps.setString(7, rs.getString("ProductImage"));
				} else {
					
					ps.setString(7, path);
				}
			}
			
			ps.setString(8, table.getValueAt(table.getSelectedRow(), 0).toString());
			ps.executeUpdate();
			
			setClear();
			fetchData();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void updateImage() {
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3306/AppsToon", "root", "");
			Statement s = c.createStatement();
			ResultSet rs = s.executeQuery(
					"SELECT ProductImage "
					+ "FROM Product "
					+ "WHERE ProductImage LIKE '%" + table.getValueAt(table.getSelectedRow(), 5) + "';"
					);
			
			if (rs.next()) {
				
				
				if (rs.getString("productimage").startsWith("\\resources\\")) {
					
					icon.setIcon(new ImageIcon(ImageIO.read(getClass().getResource("/" + 
							table.getValueAt(table.getSelectedRow(), 5)))));
				} else {
					
					icon.setIcon(new ImageIcon(new ImageIcon(
							ImageIO.read(new File
									(rs.getString(1).replace("\\", "/")))).getImage().getScaledInstance(
											210, 210, Image.SCALE_DEFAULT)));
				}
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public JComboBox setGenre() {
		
		String[] list = null;
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3306/AppsToon","root","");
			Statement s = c.createStatement();
			ResultSet rs = s.executeQuery(
					"SELECT COUNT(GenreId) "
					+ "FROM Genre;"
					);
			if (rs.next()) {
				
				list = new String[rs.getInt(1) + 1];
			}
			
			rs = s.executeQuery(
					"SELECT GenreName "
					+ "FROM Genre;");
			
			int i = 1;
			list[0] = "Genre";
			while (rs.next()) {
				
				list[i] = rs.getString("GenreName");
				i++;
			}
			
			comboGenre = new JComboBox(list);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return comboGenre;
	}
}
