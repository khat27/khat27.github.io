package appsToon;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;

public class LoginForm extends JFrame{
	
	Temporary tp = new Temporary();

	private JLabel title = new JLabel("Login", SwingConstants.CENTER);
	private JLabel lUsern = new JLabel("Username");
	private JLabel lPass = new JLabel("Password");
	
	private JButton bReg = new JButton("Register");
	private JButton bSub = new JButton("Submit");
	
	private JTextField tfUsern = new JTextField(15);
	private JPasswordField tfPass = new JPasswordField(15);
	
	private JPanel mainPanel = new JPanel(new BorderLayout(10, 20));
	private JPanel buttonPanel = new JPanel(new GridLayout(1, 2, 20, 10));
	private JPanel fieldPanel = new JPanel(new GridLayout(2, 2, 10, 15));
	
	public LoginForm() {
		
		initComponents();
		actions();
		
		setContentPane(mainPanel);
		pack();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        setLocationRelativeTo(null);
        setTitle("Apps Toon");
        setVisible(true);
	}
	
	public void initComponents() {
		
		title.setFont(new Font(title.getFont().getName(), Font.BOLD, 25));
		
		fieldPanel.add(lUsern);
		fieldPanel.add(tfUsern);
		fieldPanel.add(lPass);
		fieldPanel.add(tfPass);
		fieldPanel.setBorder(BorderFactory.createEmptyBorder(0, 10, 0, 10));
		
        buttonPanel.add(bReg);
        buttonPanel.add(bSub);
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(0, 30, 0, 30));
        
        mainPanel.add(title, BorderLayout.NORTH);
        mainPanel.add(fieldPanel, BorderLayout.CENTER);
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
	}
	
	public void actions() {
		
		bReg.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				dispose();
				new RegisterForm();
			}
		});
        
        bSub.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub		
				if (tfUsern.getText().length() == 0 || tfPass.getText().length() == 0) {
					
					JOptionPane.showMessageDialog(null, "Username and password have to be filled", "Error", JOptionPane.ERROR_MESSAGE);
				} else {
					
			        try{
			        	
			        	Class.forName("com.mysql.jdbc.Driver");  
			        	Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3306/AppsToon","root","");
			        	Statement s = c.createStatement();
			        	ResultSet rs = s.executeQuery(
			        			"SELECT UserEmail, UserPassword "
			        			+ "FROM User "
			        			+ "WHERE UserEmail = '" + tfUsern.getText() + "' "
			        					+ "AND UserPassword = '" + tfPass.getText() + "';"
			        			);
			        	
			        	if (rs.first()) {
							
							dispose();
							
							rs = s.executeQuery("SELECT * FROM User "
									+ "WHERE Role = 'User' "
									+ "AND UserEmail = '" + tfUsern.getText() + "';");
							
							if (!rs.first()) {
								
								new MainFormStaff();
							} else {
								
								tp.setId(rs.getString("UserId"));
								tp.setUsern(rs.getString("UserName"));
								new MainFormUser();
							} 
						} else {
							
							JOptionPane.showMessageDialog(null, "Email or password is invalid", "Error", JOptionPane.ERROR_MESSAGE);
						}
			        }catch(Exception e1){ 
			        	
			        	System.out.println(e1);
			        }
				}
			}
		});
	}
	
	public static void main(String[] args) {
		
		SwingUtilities.invokeLater(new Runnable() {
			
			@Override
			public void run() {
				// TODO Auto-generated method stub
				new LoginForm();
			}
		});
	}
}
