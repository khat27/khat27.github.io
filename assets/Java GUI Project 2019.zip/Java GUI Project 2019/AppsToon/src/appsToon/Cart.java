package appsToon;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;

public class Cart extends JInternalFrame{
	
	Temporary tp = new Temporary();

	private DateFormat dateformat = new SimpleDateFormat("yyyy-MM-dd");
	private Date date = new Date();
	
	private JLabel uid = new JLabel("User ID:", SwingConstants.RIGHT);
	private JLabel phUid = new JLabel();
	private JLabel ldate = new JLabel("Date:", SwingConstants.RIGHT);
	private JLabel phDate = new JLabel();
	private JLabel username = new JLabel("Username:", SwingConstants.RIGHT);
	private JLabel phUsername = new JLabel();
	private JLabel totalPrice = new JLabel("Total Price:", SwingConstants.RIGHT);
	private JLabel phPrice = new JLabel();
	
	private static DefaultTableModel model = new DefaultTableModel(new Object[] {
			"Product ID",
			"Name",
			"Price",
			"Quantity"
		}, 0) {
			
			public boolean isCellEditable(int row, int column) {
				
				return false;
			};
		};
		
	private JTable table = new JTable(model);
	
	private JButton checkout = new JButton("Check Out");
	
	private JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
	private JPanel panel1 = new JPanel(new GridLayout(3, 1, 10, 10));
	private JPanel panel2 = new JPanel(new GridLayout(1, 2, 10, 10));
	private JPanel panel3 = new JPanel(new GridLayout(2, 2, 10, 10));
	private JPanel panel4 = new JPanel(new GridLayout(2, 2, 10, 10));

	public Cart() {
		// TODO Auto-generated constructor stub
		initComponents();
		
		setContentPane(mainPanel);
		setClosable(true);
		setMaximizable(true);
		pack();
		show();
	}
	
	public void initComponents() {
		
		table.getTableHeader().setReorderingAllowed(false);
		table.setFocusable(false);
		table.setRowSelectionAllowed(false);
		fetchData();
		placeholderValue();
		
		panel4.add(username);
		panel4.add(phUsername);
		panel4.add(totalPrice);
		panel4.add(phPrice);
		
		panel3.add(uid);
		panel3.add(phUid);
		panel3.add(ldate);
		panel3.add(phDate);
		
		panel2.add(panel3);
		panel2.add(panel4);
		
		panel1.add(new JLabel("Cart", SwingConstants.CENTER));
		panel1.add(panel2, BorderLayout.CENTER);
		panel1.add(new JLabel("Detail", SwingConstants.CENTER));
		panel1.getComponent(0).setFont(new Font(panel1.getComponent(0).getFont().getName(), Font.BOLD, 20));
		panel1.getComponent(2).setFont(new Font(panel2.getComponent(1).getFont().getName(), Font.BOLD, 20));
		
		mainPanel.add(panel1, BorderLayout.NORTH);
		mainPanel.add(new JScrollPane(table), BorderLayout.CENTER);
		mainPanel.add(checkout, BorderLayout.SOUTH);
		checkout.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				actions();
			}
		});
		mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
	}
	
	public void clearField() {
		
		phUid.setName("");
		phDate.setName("");
		phPrice.setName("");
		phUsername.setName("");
	}

	public void actions() {
		// TODO Auto-generated method stub
		
		String trId = generateTransaction();
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3306/AppsToon", "root", "");
			PreparedStatement ps = c.prepareStatement(
					"UPDATE Product "
					+ "SET ProductQuantity = ProductQuantity - ? "
					+ "WHERE ProductId = ?"
					);
			
			for(int i = 0; i < table.getRowCount(); i++) {
				
				ps.setString(1, table.getValueAt(i, 3) + "");
				ps.setString(2, table.getValueAt(i, 0) + "");
				ps.executeUpdate();
			}

			ps = c.prepareStatement(
					"INSERT INTO HeaderTransaction VALUES "
					+ "(?, ?, ?)"
					);
			
			ps.setString(1, trId);
			ps.setString(2, tp.getId());
			ps.setString(3, dateformat.format(date));
			ps.executeUpdate();
			
			ps = c.prepareStatement(
					"INSERT INTO DetailTransaction VALUES "
					+ "(?, ?, ?)"
					);
			for(int i = 0; i < table.getRowCount(); i++) {
										
				ps.setString(1, trId);
				ps.setString(2, table.getValueAt(i, 0) + "");
				ps.setString(3, table.getValueAt(i, 3) + "");
				ps.executeUpdate();
			}
			
			ps = c.prepareStatement(
					"DELETE FROM Cart "
					+ "WHERE UserId = ?"
					);
			ps.setString(1, tp.getId());
			ps.executeUpdate();
			
			clearField();
			
			fetchData();
		} catch (ClassNotFoundException | SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}
	
	public String generateTransaction() {
		
		String temp = "";
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3306/AppsToon", "root", "");
			Statement s = c.createStatement();
			ResultSet rs = s.executeQuery(
					"SELECT TransactionId "
					+ "FROM HeaderTransaction "
					+ "ORDER BY TransactionId DESC LIMIT 1;"
					);
			
			if (!rs.first()) {
				
				temp = "TR001";
			} else {
				
				temp = "TR" + String.format("%03d", Integer.parseInt(
						rs.getString("TransactionId").substring(2)) + 1);
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return temp;
	}
	
	public void fetchData() {
		
		model.setRowCount(0);
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/AppsToon", "root", "");
			Statement st = con.createStatement();
			ResultSet res = st.executeQuery(
					"SELECT Cart.ProductId, ProductName, ProductPrice, Qty "
							+ "FROM Cart, Product "
							+ "WHERE Cart.ProductId = Product.ProductId AND UserId LIKE '" + tp.getId() + "';"
					);
			
			while (res.next()) {
				
				model.addRow(new Object[] {
						res.getString("ProductId"),
						res.getString("ProductName"),
						res.getString("ProductPrice"),
						res.getString("Qty")
				});
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void placeholderValue() {
		
		phUid.setText(tp.getId());
		phUsername.setText(tp.getUsern());
		phDate.setText(dateformat.format(date));
		int price = 0;
		for(int i = 0; i < table.getRowCount(); i++) {
			
			price = price + (Integer.parseInt(table.getValueAt(i, 2) + "") * Integer.parseInt((String) table.getValueAt(i, 3) + ""));
		}
		phPrice.setText(price + "");
	}
	
}
