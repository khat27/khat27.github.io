package appsToon;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;

public class StaffTransactionForm extends JInternalFrame{

	Temporary tp = new Temporary();
	
	private DefaultTableModel model = new DefaultTableModel(new Object[] {
			
			"TransactionID",
			"UserID",
			"Date"
	}, 0) {
		
		public boolean isCellEditable(int row, int column) {
			
			return false;
		};
	};
	
	private DefaultTableModel model1 = new DefaultTableModel(new Object[] {
			
			"TransactionID",
			"ProductID",
			"Qty"
	}, 0) {
		
		public boolean isCellEditable(int row, int column) {
			
			return false;
		};
	};
	
	private JTable tableHeader = new JTable(model);
	private JTable tableDetail = new JTable(model1);
	
	private JLabel header = new JLabel("Transaction List", SwingConstants.CENTER);
	private JLabel detail = new JLabel("Transaction Detail", SwingConstants.CENTER);
	
	private JPanel mainPanel = new JPanel(new GridLayout(2, 1, 10, 10));
	private JPanel headerPanel = new JPanel(new BorderLayout(10, 10));
	private JPanel detailPanel = new JPanel(new BorderLayout(10, 10));
	
	public StaffTransactionForm() {
		// TODO Auto-generated constructor stub
		initComponents();
		
		setMaximizable(true);
		setClosable(true);
		setResizable(false);
		setSize(600, 500);
		show();
	}

	public void fetchData() {
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3306/AppsToon", "root", "");
			Statement s = c.createStatement();
			ResultSet rs = s.executeQuery(
					"SELECT * "
					+ "FROM HeaderTransaction "
					+ "WHERE UserId LIKE '" + tp.getId() + "';"
					);
			
			while (rs.next()) {
				
				model.addRow(new Object[] {
						
						rs.getString(1),
						rs.getString(2),
						rs.getString(3)
				});
			}
			
			rs = s.executeQuery(
					"SELECT DetailTransaction.TransactionId, ProductId, Qty "
					+ "FROM DetailTransaction JOIN HeaderTransaction "
					+ 	"ON DetailTransaction.TransactionId = HeaderTransaction.TransactionId "
					+ "WHERE UserId LIKE '" + tp.getId() + "';"
					);
			
			while (rs.next()) {
				
				model1.addRow(new Object[] {
						
						rs.getString(1),
						rs.getString(2),
						rs.getString(3)
				});
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public void initComponents() {

		tableHeader.setFocusable(false);
		tableHeader.setRowSelectionAllowed(false);
		
		tableDetail.setFocusable(false);
		tableDetail.setRowSelectionAllowed(false);
		
		fetchData();
		
		header.setFont(new Font(header.getFont().getName(), Font.BOLD, 20));
		detail.setFont(new Font(header.getFont().getName(), Font.BOLD, 20));
		
		headerPanel.add(header, BorderLayout.NORTH);
		headerPanel.add(new JScrollPane(tableHeader), BorderLayout.CENTER);
		detailPanel.add(detail, BorderLayout.NORTH);
		detailPanel.add(new JScrollPane(tableDetail), BorderLayout.CENTER);
		
		mainPanel.add(headerPanel);
		mainPanel.add(detailPanel);
		
		setContentPane(mainPanel);
	}
}
