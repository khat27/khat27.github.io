package appsToon;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JDesktopPane;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.SwingUtilities;

public class MainFormUser extends JFrame{

	private JDesktopPane dp = new JDesktopPane();
	
	private JMenuBar mb = new JMenuBar();
	
	private JMenu transaction = new JMenu("Transaction");
	
	private JMenuItem buy = new JMenuItem("Buy Product");
	private JMenuItem view = new JMenuItem("View Transaction");
	
	private JMenuItem logout = new JMenuItem("Logout");
	
	public MainFormUser() {
		// TODO Auto-generated constructor stub
		
		buy.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				
				SwingUtilities.invokeLater(new Runnable() {
					
					@Override
					public void run() {
						// TODO Auto-generated method stub
						BuyProductForm bp = new BuyProductForm();
						
						getContentPane().add(bp);
						getContentPane().add(new Cart());
					}
				});
			}
		});
		
		logout.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				dispose();
				new LoginForm();
			}
		});
		
		transaction.add(view);
		
		view.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				getContentPane().add(new UserTransactionForm());
			}
		});
		transaction.add(buy);
		
		mb.add(transaction);
		mb.add(logout);
		
		setJMenuBar(mb);
		
		setContentPane(dp);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setExtendedState(getExtendedState() | MAXIMIZED_BOTH);
		setSize(700, 600);
		setLocationRelativeTo(null);
		setVisible(true);
	}
	
	

	public void initComponents() {
		
		
	}
}
