package appsToon;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingConstants;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;

public class BuyProductForm extends JInternalFrame{
	
	Temporary tp = new Temporary();

	private JLabel title = new JLabel("Our Products", SwingConstants.CENTER);
	private JLabel pId = new JLabel("Product ID");
	private JLabel pName = new JLabel("Product Name");
	private JLabel pPrice = new JLabel("Produc Price");
	private JLabel genre = new JLabel("Genre Name");
	private JLabel qty = new JLabel("Quantity");
	private JLabel rating = new JLabel("Rating");
	private JLabel phProductId = new JLabel("");
	private JLabel phProductName = new JLabel("");
	private JLabel phProductPrice = new JLabel("");
	private JLabel phGenre = new JLabel("");
	private JLabel phRating = new JLabel("");
	private JLabel productImage = new JLabel();
	
	private JSpinner spinner = new JSpinner(new SpinnerNumberModel(1, 0, null, 1));
	
	private JButton addToCart = new JButton("Add to Cart");
	
	private DefaultTableModel model = new DefaultTableModel(new Object[] {
			
			"ProductID",
			"GenreName",
			"ProductName",
			"ProductPrice",
			"ProductQuantity",
			"ProductImage",
			"ProductRating"
	}, 0) {
		
		public boolean isCellEditable(int row, int col) {
			return false;
		};
	};
	
	private JTable table = new JTable(model);
	
	private JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
	private JPanel panel1 = new JPanel(new GridLayout(2, 1, 10, 10));
	private JPanel panel2 = new JPanel(new GridLayout(1, 3, 10, 10));
	private JPanel labelPanel = new JPanel(new GridLayout(6, 1, 5, 5));
	private JPanel placeholderPanel = new JPanel(new GridLayout(6, 1, 5, 5));
	private JPanel buttonPanel = new JPanel();
	private JPanel quantityPanel = new JPanel(new BorderLayout());
	
	public BuyProductForm() {
		// TODO Auto-generated constructor stub
		title.setFont(new Font(title.getFont().getName(), Font.BOLD, 20));
		
		fetchData();	
		initComponents();
		actions();
		
		table.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
			
			@Override
			public void valueChanged(ListSelectionEvent arg0) {
				// TODO Auto-generated method stub
				selectData();
			}
		});
		
		setContentPane(mainPanel);	
		setTitle("Buy Product");
		setClosable(true);
		setMaximizable(true);
		show();
		setSize(800, 560);
	}
	
	public void selectData() {
		
		try {
			
			phProductId.setText((String) table.getValueAt(table.getSelectedRow(), 0));
			phProductName.setText((String) table.getValueAt(table.getSelectedRow(), 2));
			phProductPrice.setText("" + table.getValueAt(table.getSelectedRow(), 3));
			phGenre.setText((String) table.getValueAt(table.getSelectedRow(), 1));
			phRating.setText((String) table.getValueAt(table.getSelectedRow(), 6));
			updateImage();
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	public void actions() {
		
		addToCart.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				addToCart();
			}
		});
	}
	
	public void updateImage() {
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3306/AppsToon","root","");
			Statement s = c.createStatement();
			ResultSet rs = s.executeQuery(
					"SELECT ProductImage "
					+ "FROM Product "
					+ "WHERE ProductImage LIKE '%" + table.getValueAt(table.getSelectedRow(), 5) + "';"
					);
			
			if(rs.next()) {
								
				if (rs.getString("ProductImage").startsWith("\\resources\\")) {
					
					productImage.setIcon(new ImageIcon(ImageIO.read(getClass().getResource("/" + 
							table.getValueAt(table.getSelectedRow(), 5)))));
				} else {
					
					productImage.setIcon(new ImageIcon(ImageIO.read(new File(
							rs.getString("ProductImage").replace("\\", "/")))));
				}
			}
			
			
		} catch (ClassNotFoundException | SQLException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void fetchData() {
		
		model.setRowCount(0);
		
		try {
			
			Class.forName("com.mysql.jdbc.Driver");
			Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3306/AppsToon","root","");
			Statement s = c.createStatement();
			ResultSet rs = s.executeQuery(
					"SELECT ProductId, " + 
					"GenreName, " + 
					"ProductName, " + 
					"ProductPrice, " + 
					"ProductQuantity, " + 
					"CASE " + 
						"WHEN productimage LIKE '/resources/%' "
						+ "THEN SUBSTRING(ProductImage, (LENGTH(ProductImage) - "
						+ "LOCATE('/', REVERSE(ProductImage)) + 2), LOCATE('/', REVERSE(ProductImage))) " + 
					"ELSE " + 
					"SUBSTRING(ProductImage, (LENGTH(ProductImage) - LOCATE('\\\\', reverse(ProductImage)) + 2), "
					+ "LOCATE('\\\\', REVERSE(ProductImage))) " + 
					"END AS abc, " + 
					"ProductRating " + 
					"FROM Product, Genre " + 
					"WHERE Product.GenreId = Genre.GenreId;");
			
			while (rs.next()) {
				
				model.addRow(new Object[] {
						rs.getString(1), 
						rs.getString(2), 
						rs.getString(3), 
						rs.getInt(4), 
						rs.getInt(5), 
						rs.getString(6), 
						rs.getString(7)});
			}
			
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void addToCart() {
		
		if (table.getSelectedColumn() == -1) {
												
			JOptionPane.showMessageDialog(null, "Product must be selected", "Message", JOptionPane.ERROR_MESSAGE);
		} else if (spinner.getValue().toString().equals("0")) {
			
			JOptionPane.showMessageDialog(null, "Minimum quantity selected is 1", "Message", JOptionPane.ERROR_MESSAGE);
		} else if (Integer.parseInt(spinner.getValue() + "") > Integer.parseInt(
				table.getValueAt(table.getSelectedRow(), 4) + "")) {
			
			JOptionPane.showMessageDialog(null, "Quantity cannot be bigger than stock", "Message", JOptionPane.ERROR_MESSAGE);
		} else {
			
			try {
				Class.forName("com.mysql.jdbc.Driver");
				Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3306/AppsToon", "root", "");
				Statement s = c.createStatement();
				PreparedStatement ps;
				ResultSet rs = s.executeQuery(
						"SELECT ProductId "
						+ "FROM Cart "
						+ "WHERE ProductId LIKE '" + table.getValueAt(table.getSelectedRow(), 0) + "';"
						);
				if (rs.next()) {
					
					ps = c.prepareStatement(
							"UPDATE Cart "
							+ "SET Qty = Qty + ? "
							+ "WHERE ProductId LIKE ?"
							);
					ps.setString(1, spinner.getValue() + "");
					ps.setString(2, table.getValueAt(table.getSelectedRow(), 0) + "");
					ps.executeUpdate();
				} else {
					
					ps = c.prepareStatement(
							"INSERT INTO Cart VALUES (?, ?, ?);"
							);
					ps.setString(1, tp.getId());
					ps.setString(2, table.getValueAt(table.getSelectedRow(), 0) + "");
					ps.setString(3, spinner.getValue() + "");
					
					ps.executeUpdate();
					
					new Cart();
				}
				
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			tp.setTotal(Integer.parseInt(spinner.getValue() + "") * Integer.parseInt(phProductPrice.getText()));
		}
	}
	
	public void initComponents() {
		
		table.getTableHeader().setReorderingAllowed(false);
		table.setFocusable(false);
		table.setRowSelectionAllowed(true);
		
		labelPanel.add(pId);
		labelPanel.add(pName);
		labelPanel.add(pPrice);
		labelPanel.add(genre);
		labelPanel.add(qty);
		labelPanel.add(rating);

		quantityPanel.add(spinner, BorderLayout.CENTER);
		
		placeholderPanel.add(phProductId);
		placeholderPanel.add(phProductName);
		placeholderPanel.add(phProductPrice);
		placeholderPanel.add(phGenre);
		placeholderPanel.add(quantityPanel);
		placeholderPanel.add(phRating);
		
		productImage.setIcon(new ImageIcon(new ImageIcon(
				getClass().getResource("/No_Image.jpg")).getImage().getScaledInstance(
						180, 180, Image.SCALE_SMOOTH)));
		
		panel2.add(productImage);
		panel2.add(labelPanel);
		panel2.add(placeholderPanel);
		panel2.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
		
		panel1.add(new JScrollPane(table));
		panel1.add(panel2);
		
		buttonPanel.add(addToCart);
		
		mainPanel.add(title, BorderLayout.NORTH);
		mainPanel.add(panel1, BorderLayout.CENTER);
		mainPanel.add(buttonPanel, BorderLayout.SOUTH);
		mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
	}
}
