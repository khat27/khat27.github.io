create database AppsToon;

use AppsToon;

create table `User`(
UserId char(5) primary key check(UserId regexp binary '^US[0-9][0-9][0-9]'),
UserName varchar(25),
UserEmail varchar(50),
UserPassword varchar(20),
UserGender varchar(6),
UserDOB date,
UserPhoneNumber varchar(12),
UserAddress varchar(30),
`Role` varchar(5)
);

create table Genre(
GenreId char(5) primary key,
GenreName varchar(15)
);

create table Product(
ProductId char(5) primary key check(ProductId regexp binary '^PD[0-9][0-9][0-9]'),
GenreId char(5),
ProductName varchar(50),
ProductPrice int,
ProductQuantity int,
ProductImage varchar(255),
ProductRating int,
foreign key (GenreId) 
	references Genre(GenreId)
);

create table HeaderTransaction(
TransactionId char(5) primary key check(TransactionId regexp binary '^TR[0-9][0-9][0-9]'),
UserId char(5),
TransactionDate date,
foreign key (UserId) 
	references User(UserId)
);

create table DetailTransaction(
TransactionId char(5),
ProductId char(5),
Qty int,
primary key(TransactionId, ProductId),
foreign key(TransactionId) 
	references HeaderTransaction(TransactionId),
foreign key(ProductId) 
	references Product(ProductId)
    on delete cascade
);

create table Cart(
UserId char(5),
ProductId char(5),
Qty int,
primary key(UserId, ProductId),
foreign key(UserId) 
	references `User`(UserId),
foreign key(ProductId) 
	references Product(ProductId)
    on delete cascade
);

insert into User values
('US000', 'Admin', 'Admin', 'Admin', 'Male', '2000-01-01', '12345689012', 'Admin Street', 'Staff'),
('US001', 'user', 'user', 'user', 'Male', '2000-01-01', '12345689012', 'Admin Street', 'User');

insert into Genre values
('GE001', 'Drama'),
('GE002', 'Fantasi'),
('GE003', 'Komedi'),
('GE004', 'Aksi'),
('GE005', 'Slice Of Life'),
('GE006', 'Romantis'),
('GE007', 'Horor'),
('GE008', 'Webnovel');